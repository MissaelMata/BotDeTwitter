# YouTube Video: https://www.youtube.com/watch?v=wlnx-7cm4Gg
# Variables that contains the user credentials to access Twitter API 

ACCESS_TOKEN = ""
ACCESS_TOKEN_SECRET = ""
CONSUMER_KEY = ""
CONSUMER_SECRET = ""